# Report

## Introduction

This is a report for the module 09 assignment. The assignment was to create a blog using HTML and CSS. The purpose of this blog to test student's skill so far taught them in the course.

## Blog

The blog can be found at [https://jamesmccaffrey.github.io/](https://jamesmccaffrey.github.io/).


## Challenges

The main challenge I faced was getting the blog to work on GitHub Pages. I had to change the baseurl in the _config.yml file to get it to work. I also had to change the url in the _config.yml file to get the links to work correctly.

## Conclusion

I found the assignment to be quite easy. I had some experience with Jekyll from a previous assignment. I also had some experience with GitHub Pages from a previous assignment. I found the Hydeout theme to be quite easy to use. I did not have any problems with the assignment.

A written report detailing the design and implementation of your blog, including a description of any challenges you faced and how you overcame them.

