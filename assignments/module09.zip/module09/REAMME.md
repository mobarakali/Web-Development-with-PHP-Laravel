# Report

## Introduction

This is a report for the module 09 assignment. The assignment was to create a blog using HTML and CSS. The purpose of this blog to test student's skill so far taught them in the course.

## Blog

The blog can be found live at [https://demos.mobarak.com.bd/module09/](https://demos.mobarak.com.bd/module09/).


## Challenges

The main challenge I faced was getting the blog to work on Live Server. ``include_once()`` is not working on live server but on my Local Server. After lot of frustation [Stake Overflow](https://stackoverflow.com/questions/23016133/require-once-not-working-on-live-server) helped me to solve the issue.

## Conclusion

I found the assignment to be quite easy. I had some experience with from from previous assignments. I also had experience with Buildign web Pages with froms Using Bootstrap. I did not have any problems with the assignment.


